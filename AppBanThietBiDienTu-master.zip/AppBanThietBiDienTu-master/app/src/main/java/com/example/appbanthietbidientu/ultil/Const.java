package com.example.appbanthietbidientu.ultil;

public class Const {
    public static final String KEY_USERNAME="tenkhachhang";
    public static final String KEY_SDT="sodienthoai";
    public static final String KEY_EMAIL="email";
}
